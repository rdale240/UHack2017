from twitter import *
import json

token = "937022771862917125-nf2TWDbpvPMifaxW9CoscoSIjxPxzsz"
token_secret = 	"jPRcm4WRfjkfPgnxfC5bAE16AEUiPTltvfUao5VoQNvD2"
consumer_key = 	"EJCObrUdZdjHxaibMjN8EMT3S"
consumer_secret = "oKvIkUIYfSbzvBwASHpDZ4rxHnBMnddVOQzrgRnURE5Y0H0UyN"

t = Twitter(auth=OAuth(token, token_secret, consumer_key,consumer_secret), retry=True)

# test = t.statuses.home_timeline()
# print (test)

# test2 = []
# test2 = t.search.tweets(q="?l=en&q=#bitcoin")

# print (test2)

# def twitSearch (param):
#     results = []
#     for x in range (100):
#         results.append( t.search.tweets( q="%s" % (param) ))
#     return results

positive_file = open("positive_tweets.dat", "w+")
negative_file = open("negative_tweets.dat", "w+")

negative_search = "bitcoin%20(shitcoin%20OR%20speculation%20OR%20bubble%20OR%20bad%20OR%20scam%20OR%20bust%20OR%20bear%20OR%20volatile%20OR%20volatility%20OR%20low%20OR%20lost%20OR%20lose%20OR%20trollcoin%20OR%20delusion%20OR%20fud%20OR%20drop%20OR%20shill%20OR%20dump%20OR%20pump%20OR%20outages%20OR%20outlawed%20OR%20illegal%20OR%20flippening%20OR%20nosedive%20OR%20MtGox%20OR%20crash%20OR%20crashes%20OR%20hack%20OR%20ponzi%20OR%20spam%20OR%20decline%20OR%20sell)%20since%3A2010-10-10%20until2010-10-11"

positive_search = "bitcoin%20(Rocket%20OR%20Moon%20OR%20Explode%20OR%20awesome%20OR%20cool%20OR%20bull%20OR%20accepting%20OR%20high%20OR%20growth%20OR%20hodl%20OR%20fomo%20OR%20dark%20OR%20web%20OR%20whale%20OR%20mass%20OR%20mining%20OR%20hold%20OR%20buy)%20since%3A2017-10-10%20until2010-10-11"


def twitSearch (parameter):
    results = t.search.tweets("%s" % (parameter) )
    print (str(results))
    return results

def posSearch ():
    terms = "bitcoin (Rocket OR Moon OR Explode OR awesome OR cool OR bull OR accepting OR high OR growth OR hodl OR fomo OR dark OR web OR whale OR mass OR mining OR hold OR buy) since:2010-10-10"
    results = t.search.tweets(q="%s" % terms)
    return results

def negSearch ():
    terms = "bitcoin (shitcoin OR speculation OR bubble OR garbage OR bad OR scam OR bust OR bear OR volatile OR volatility OR low OR lost OR lose OR loses OR trollcoin OR delusion OR fud OR drop OR shill OR dump OR pump OR outages OR outlawed OR illegal OR flippening OR nosedive OR MtGox OR crash OR crashes OR hack OR hacker OR ponzi OR spam OR noob OR decline OR sell) since:2010-10-10"
    results = t.search.tweets(q="%s" % terms)
    return results

def text(searchDict):
    num_elem = len(searchDict['statuses'])
    print ("number of elements: " + str(num_elem))

    output = []
    for x in range (num_elem):
        current_tweet = searchDict['statuses'][x]
        current_date = searchDict['statuses'][x]['created_at']
        current_text = searchDict['statuses'][x]['text']
        # is_RT = searchDict['statuses'][x]['retweeted']
        #
        # if (is_RT == False):
        output.append( (searchDict['statuses'][x]['text']) )
        print (searchDict['statuses'][x]['created_at'] + "\t" + searchDict['statuses'][x]['text'] + "\n")
    return output

# searchTerm = input("Enter test search term:    ")
# positiveResults = twitSearch(positive_search)
# negativeResults = twitSearch(negative_search)

positiveResults = posSearch()
negativeResults = negSearch()

pos_string = str(text(positiveResults))
neg_string = str(text(negativeResults))
# print ("positive results" + pos_string)
# print ("negative results" + pos_string)
positive_file.write( pos_string )
negative_file.write( neg_string )

# print (searchResults['statuses'][0]['text'])
# print (text(searchResults))


# print (searchResults)

# for x in range (2):
#     # print (searchResults[x]['user']['screen_name'])
#     print (searchResults[x])
#     print ("\n\n")
