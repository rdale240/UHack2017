import json
import datetime
import random
from decimal import Decimal
from twitter import *

token = "937022771862917125-nf2TWDbpvPMifaxW9CoscoSIjxPxzsz"
token_secret = 	"jPRcm4WRfjkfPgnxfC5bAE16AEUiPTltvfUao5VoQNvD2"
consumer_key = 	"EJCObrUdZdjHxaibMjN8EMT3S"
consumer_secret = "oKvIkUIYfSbzvBwASHpDZ4rxHnBMnddVOQzrgRnURE5Y0H0UyN"

t = Twitter(auth=OAuth(token, token_secret, consumer_key,consumer_secret), retry=True)

negative_search = "bitcoin%20(shitcoin%20OR%20speculation%20OR%20bubble%20OR%20bad%20OR%20scam%20OR%20bust%20OR%20bear%20OR%20volatile%20OR%20volatility%20OR%20low%20OR%20lost%20OR%20lose%20OR%20trollcoin%20OR%20delusion%20OR%20fud%20OR%20drop%20OR%20shill%20OR%20dump%20OR%20pump%20OR%20outages%20OR%20outlawed%20OR%20illegal%20OR%20flippening%20OR%20nosedive%20OR%20MtGox%20OR%20crash%20OR%20crashes%20OR%20hack%20OR%20ponzi%20OR%20spam%20OR%20decline%20OR%20sell)%20since%3A2010-10-10%20until2010-10-11"

positive_search = "bitcoin%20(Rocket%20OR%20Moon%20OR%20Explode%20OR%20awesome%20OR%20cool%20OR%20bull%20OR%20accepting%20OR%20high%20OR%20growth%20OR%20hodl%20OR%20fomo%20OR%20dark%20OR%20web%20OR%20whale%20OR%20mass%20OR%20mining%20OR%20hold%20OR%20buy)%20since%3A2017-10-10%20until2010-10-11"

def text(searchDict):
    num_elem = len(searchDict['statuses'])
    print ("number of elements: " + str(num_elem))

    output = []
    for x in range (num_elem):
        current_tweet = searchDict['statuses'][x]
        current_date = searchDict['statuses'][x]['created_at']
        d = datetime.strptime(current_date,'%a %b %d %H:%M:%S +0000 %Y').replace(tzinfo=pytz.UTC)

        current_text = current_tweet['text']
        current_id = current_tweet['id']
        # is_RT = searchDict['statuses'][x]['retweeted']
        #
        # if (is_RT == False):
        output.append( (searchDict['statuses'][x]['text']) )
        print ("ID: " + str(current_id) + " " + searchDict['statuses'][x]['created_at'] + "\t" + searchDict['statuses'][x]['text'] + "\n")
    return output

def posSearch (date):
    terms = "bitcoin (Rocket OR Moon OR Explode OR awesome OR cool OR bull OR accepting OR high OR growth OR hodl OR fomo OR dark OR web OR whale OR mass OR mining OR hold OR buy) "
    terms += "since:%s" % (date)
    results = t.search.tweets(q="%s" % terms)
    return results

def negSearch (date):
    terms = "bitcoin (shitcoin OR speculation OR bubble OR garbage OR bad OR scam OR bust OR bear OR volatile OR volatility OR low OR lost OR lose OR loses OR trollcoin OR delusion OR fud OR drop OR shill OR dump OR pump OR outages OR outlawed OR illegal OR flippening OR nosedive OR MtGox OR crash OR crashes OR hack OR hacker OR ponzi OR spam OR noob OR decline OR sell) "
    terms += "since:%s" % (date)
    results = t.search.tweets(q="%s" % terms)
    return results

data = {}

#use 1200 days later
for x in range (10):
    today = datetime.datetime.now()
    yesterday = today - datetime.timedelta(days=x)
    date = yesterday.strftime("%Y-%m-%d")
    pos_val = (random.random())
    neg_val = (random.random()) * -1
    avg_val = (neg_val + pos_val)/2
    avg = round(Decimal(avg_val), 3)

    data[date] = {}
    data[date]['tweet_type'] = {}
    data[date]['tweet_type']['id'] = {}
    data[date]['tweet_type']['id']['tweet_info'] = {'text':'', 'date':'', 'sentiment':''}


    pos_results = posSearch(date)
    neg_results = negSearch(date)

    # print (pos_results)
    # print (neg_results)

    num_pos_elem = len(pos_results['statuses'])
    num_neg_elem = len(neg_results['statuses'])

#positive tweets
    for x in range (num_pos_elem):
        current_pos_tweet = pos_results['statuses'][x]
        # print (current_pos_tweet)
        current_pos_date = current_pos_tweet['created_at']
        d = datetime.datetime.strptime(current_pos_date,'%a %b %d %H:%M:%S +0000 %Y')

        current_pos_text = current_pos_tweet['text']
        current_pos_id = current_pos_tweet['id']
        # data[date]['posTweets'][current_pos_id] = current_pos_text
        data[date]['tweet_type'] = str(pos_results)
        data[date][pos_results][current_pos_id] = str(current_pos_id)
        data[date][pos_results][current_pos_id]['tweet_info'] = {'text': str(current_pos_text), 'date': str(current_pos_date), 'sentiment': str(avg)}

#negative tweets
    for x in range (num_neg_elem):
        current_neg_tweet = neg_results['statuses'][x]
        # print (current_neg_tweet)
        current_neg_date = current_neg_tweet['statuses'][x]['created_at']
        d = datetime.datetime.strptime(current_pos_date,'%a %b %d %H:%M:%S +0000 %Y')

        current_neg_text = current_neg_tweet['text']
        current_neg_id = current_neg_tweet['id']
        # data[date]['negTweets'][current_neg_id] = current_neg_text
        # data[date] = {'sentiment':str(avg), {'negTweets': {current_neg_id: {'text': current_neg_text, 'date':current_neg_date}}}}
        data[date] = str(avg)
        data[date]['tweet_type'] = str(neg_results)
        data[date][str(neg_results)]['id'] = str(current_neg_id)
        data[date][str(neg_results)][str(current_neg_id)]['tweet_info'] = {'text': str(current_neg_text), 'date': str(current_neg_date), 'sentiment': str(avg)}

print (str(data))

with open('dates.json', 'w+') as outfile:
    json.dump(data, outfile)


# print (str(json_data))
